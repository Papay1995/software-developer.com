$(document).ready(function(){
    $(".navbar-toggler-icon").click(function(){
    $(".navbar-toggler-icon").toggleClass("open");
  });
});




$(function () {
        var header = $(".start-style");
        $(window).scroll(function () {
            var scroll = $(window).scrollTop();

            if (scroll >= 10) {
                header.removeClass('start-style').addClass("scroll-on");
            } else {
                header.removeClass("scroll-on").addClass('start-style');
            }
        });
    });



$('.navbar-toggler-icon-item').click(function() {
  $(body).addClass('fixed-body');
});

$('.banner-slider').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    slideTransition: 'linear',
    autoplayTimeout: 6000,
    autoplaySpeed: 6000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});

$('.product-slider').owlCarousel({
    loop:true,
    margin:30,
    nav:true,
    dots: false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
});



$(document).ready(function(){
    $('#nav-icon3').click(function(){
        $(this).toggleClass('open');
    });
});